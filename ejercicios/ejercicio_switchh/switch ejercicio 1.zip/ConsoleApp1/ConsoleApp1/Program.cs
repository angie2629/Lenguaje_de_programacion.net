﻿using System;
using System.Collections;
using System.Linq;

namespace ConsoleApp1
{
        class Programa
        {
            static void Main(string[] args)
            {

                int valor = 1;
                while (valor != 9)
                {

                    Console.WriteLine("Elija la opcion del menu que desea realizar\n");
                    Console.WriteLine(" EJERCICIOS\n" +

                    "| 1. Numero par o impar             | \n" +
                    "| 2. Tabla de multiplicar del 1-10  | \n" +
                    "| 3. Las tablas de multiplicar      | \n" +
                    "| 4. Numero primo o no              | \n" +
                    "| 5. Vector ascendente              | \n" +
                    "| 6. Vector nombre y edad           | \n" +
                    "| 7. Vector mayor hasta el menor    | \n" +
                    "| 8. Palabra palíndroma o no        | \n" +
                    "| 9. Salir                          | \n" +
                    "|                                   | \n" +
                    "| \n");

                    valor = Convert.ToInt32(Console.ReadLine());
                    Console.Clear();

                    switch (valor)
                    {

                        case 1:

                            {
                                int numero;
                                numero = ' ';

                                Console.Write("Digite un numero:\n");
                                numero = Int32.Parse(Console.ReadLine());

                                if (numero % 2 == 0)
                                {
                                    Console.WriteLine("el numero digitado es par");

                                }
                                else
                                {
                                    Console.WriteLine("el numero digitado es impar");

                                }
                                Console.ReadKey();

                            }
                            break;
                        case 2:

                            {
                                Console.Write("Tablas de multiplicar del 1 al 10");

                                {
                                    int numero;

                                    Console.WriteLine("Ingrese un numero");
                                    numero = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine(" ");

                                    for (int i = 1; i <= 12; i++)
                                    {
                                        int operacion = numero * i;

                                        Console.WriteLine("{0} x {1} = {2}", numero, i, operacion);

                                    }
                                    Console.ReadKey();
                                }
                            }
                            break;
                        case 3:

                            {
                                Console.Write("tablas del 2 al 9 ; cada una del 1 al 10");
                                Console.WriteLine("Bienvenido estas son las tablas de multiplicar");

                                for (int i = 2; i <= 9; i++)
                                {
                                    Console.WriteLine("\n");
                                    Console.WriteLine("Tabla de multiplicar del {0}", i);
                                    Console.WriteLine("\n");


                                    for (int a = 1; a <= 10; a++)
                                    {
                                        Console.WriteLine("\n");
                                        Console.WriteLine("{0} * {1} = {2}", i, a, (i * a));
                                        Console.ReadKey();

                                    }
                                }
                            }

                            break;
                        case 4:

                            {
                                Console.Write("numero primo o no");

                                int dato = 0;
                                int numero;

                                Console.WriteLine("Digite un numero");
                                numero = Convert.ToInt32(Console.ReadLine());

                                for (int a = 1; a < (numero + 1); a++)
                                {
                                    if (numero % a == 0)
                                    {
                                        dato++;
                                    }
                                }
                                if (dato == 2)
                                {
                                    Console.WriteLine(numero + " " + "Si es un numero primo");

                                }
                                else
                                {
                                    Console.WriteLine(numero + " " + "No es un numero primo");
                                }
                                Console.ReadKey();
                            }

                            break;
                        case 5:

                            {
                                Console.Write("vectores en forma ascendente");


                                string palabra = "reconocer";
                                string reverse = string.Empty;

                                Stack pila = new Stack();

                                foreach (var c in palabra.ToArray())
                                    pila.Push(c);

                                while (pila.Count > 0)
                                    reverse += pila.Pop();

                                if (reverse.Equals(palabra))
                                    Console.WriteLine("Es palindromo");
                                else
                                    Console.WriteLine("No es ....");

                                Console.ReadKey();
                            }
                            break;
                        case 6:

                            {

                                Console.Write("definir si existe el usuario y mostrar su edad");
                                int[] edad = { 12, 50, 23, 10, 18, 35, 41, 85, 16, 45 };
                                string[] nombres = { "juan", "maria", "tereza", "pedro", "javier", "ana", "diana", "jorge", "dayana", "lady" };

                                int t = edad.Length;
                                string usuario;

                                Console.WriteLine(" " + "Digite un nombre");
                                usuario = Console.ReadLine();

                                int i;
                                for (i = 0; i < t; i++)
                                {
                                    if (usuario == nombres[i])
                                    {
                                        Console.WriteLine(" " + "su nombre es: " + nombres[i] + " y su edad correspondiente es: " + edad[i]);
                                    }

                                }
                                Console.ReadKey();
                            }
                            break;
                        case 7:

                            {
                                Console.Write("vector menor y mayor");

                                int[] edad = { 12, 50, 23, 10, 18, 35, 41, 85, 16, 45 };
                                string[] n = { "juan", "maria", "tereza", "pedro", "javier", "ana", "diana", "jorge", "dayana", "lady" };

                                int mayor = edad[0], min = edad[0];
                                string menor = n[0], nommax = n[0];

                                int i = 0;
                                for (i = 0; i < 10; i++)
                                {
                                    if (edad[i] > mayor)
                                    {
                                        mayor = edad[i];
                                        nommax = n[i];
                                    }
                                    else if (edad[i] < min)
                                    {
                                        min = edad[i];
                                        menor = n[i];
                                    }
                                }

                                Console.Write("\n\nLa persona mayor es " + nommax + " y su edad es " + mayor);
                                Console.WriteLine(" ");
                                Console.Write("\n\nLa persona menor es " + menor + " y su edad es " + min);
                                Console.WriteLine(" ");
                                Console.ReadKey();
                            }
                            break;
                        case 8:

                            {

                                string str = string.Empty;
                                Console.WriteLine("Ingresa una palabra");
                                string s = Console.ReadLine();

                                int w = s.Length;

                                for (int j = w - 1; j >= 0; j--)
                                {
                                    str = str + s[j];
                                }
                                if (str == s)
                                {
                                    Console.WriteLine(s + " si es palindrome");
                                }
                                else
                                {
                                    Console.WriteLine(s + " no es palindrome");
                                }
                                Console.WriteLine(str);
                            }

                            Console.ReadKey();
                            break;
                        case 9:
                            {

                                Console.Write("Salir");
                                break;

                            }
                    }

                }

            }
        }
    }
