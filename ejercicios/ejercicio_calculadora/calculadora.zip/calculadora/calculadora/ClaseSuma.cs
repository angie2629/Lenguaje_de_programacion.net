﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadora
{
    class ClaseSuma
    {
        //public double num1 { get; set; }
        //public double num2 { get; set; }

        public double Suma(double num1, double num2)
        {
            double S;

            S = num1 + num2;
            return S;

        }
    }
}
 
    

            

