﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora
{
    public partial class Calculadoraa : Form
    {
        double num1;
        double num2;
        string operador;
        public Calculadoraa()
        {
            InitializeComponent();
        }

        calculadora.ClaseSuma obj1 = new calculadora.ClaseSuma();
        calculadora.ClaseResta obj2 = new calculadora.ClaseResta();
        calculadora.ClaseMultiplicacion obj3 = new calculadora.ClaseMultiplicacion();
        calculadora.ClaseDivision obj4 = new calculadora.ClaseDivision();
        calculadora.ClaseFactorial obj5 = new calculadora.ClaseFactorial();



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + "0";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            operador = "/";
            num1 = double.Parse(BtnOperaciones.Text);
            BtnOperaciones.Clear();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            operador = "*";
            num1 = double.Parse(BtnOperaciones.Text);
            BtnOperaciones.Clear();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            
            operador = "-";
            num1 = double.Parse(BtnOperaciones.Text);

            BtnOperaciones.Clear();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            operador = "+";
            num1 = double.Parse(BtnOperaciones.Text);
            BtnOperaciones.Clear();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + ".";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + "9";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + "8";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + "7";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + "6";
        }

        private void button17_Click(object sender, EventArgs e)
        {
            operador = "F";
            num1 = double.Parse(BtnOperaciones.Text);
            BtnOperaciones.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + "4";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + "3";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + "2";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + "1";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            BtnOperaciones.Text = BtnOperaciones.Text + "5";
        }

        public void button11_Click_1(object sender, EventArgs e)
        {
            
 
            double Sum;
            double Res;
            double Mul;
            double Div;
            double Fac;

            switch (operador) 
            {
                case "+":
                    num2 = double.Parse(BtnOperaciones.Text);
                    Sum = obj1.Suma((num1), (num2));
                    Resultado.Text = Sum.ToString();
                    BtnOperaciones.Clear();
                    break;


                case "-":
                    num2 = double.Parse(BtnOperaciones.Text);
                    Res = obj2.Resta((num1), (num2));
                    Resultado.Text = Res.ToString();
                    BtnOperaciones.Clear();
                    break;

                case "*":
                    num2 = double.Parse(BtnOperaciones.Text);
                    Mul = obj3.Multiplicacion((num1), (num2));
                    Resultado.Text = Mul.ToString();
                    BtnOperaciones.Clear();
                    break;

                case "/":
                    num2 = double.Parse(BtnOperaciones.Text);
                    Div = obj4.Division((num1), (num2));
                    Resultado.Text = Div.ToString();
                    BtnOperaciones.Clear();
                    break;

                case "F":
                    
                    Fac = obj5.Factorial(num1);
                    Resultado.Text = Fac.ToString();
                    BtnOperaciones.Clear();
                    break;
            }
        }

        private void Operaciones_TextChanged(object sender, EventArgs e)
        {
           //BtnOperaciones.Text = BtnOperaciones.Text.Substring(0, BtnOperaciones.Text.Count() - 0);
        }

        private void Resultado_TextChanged(object sender, EventArgs e)
        {
            
            }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            Resultado.Text = Resultado.Text.Substring(0, Resultado.Text.Count() - 1);
          
        }

        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }
    }
    }

