﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadora
{
    public class ClaseFactorial
    {
        public double Factorial(double n1)
        {
            double F;

            F = 1;

            for (int i = 2; i <= n1; i++)
            {
                F = F * i;
            }
            return F;
        }
    }
}
