﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadora
{
    class ClaseDivision
    {
        public double num1 { get; set; }
        public double num2 { get; set; }

        public double Division(double num1, double num2)
        {
            double D;

            D = num1 / num2;
            return D;

        }
    }
}
