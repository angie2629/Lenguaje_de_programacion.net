﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadora
{
    class ClaseMultiplicacion
    {
        public double num1 { get; set; }
        public double num2 { get; set; }

        public double Multiplicacion(double num1, double num2)
        {
            double M;

            M = num1 * num2;
            return M;

        }
    }
}
