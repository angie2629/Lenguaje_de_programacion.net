﻿namespace System.Windows.Input
{
    internal class KeyConverter
    {
    }
}