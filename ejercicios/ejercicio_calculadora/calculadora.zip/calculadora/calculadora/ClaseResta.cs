﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadora
{
    class ClaseResta
    {
        public double num1 { get; set; }
        public double num2 { get; set; }

        public double Resta(double num1, double num2)
        {
            double R;

            R = num1 - num2;
            return R;

        }
    }
}
